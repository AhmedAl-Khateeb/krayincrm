<div class="row tems-center grid grid-cols-[2fr_7fr_.1fr] items-center gap-2.5 border-b px-8 py-4 dark:border-gray-800">
    <div class="flex items-center gap-6">
        <div class="shimmer h-6 w-6"></div>

        <div class="shimmer h-[17px] w-[150px]"></div>
    </div>

    <div class="flex w-full items-center justify-between gap-4">
        <div class="shimmer h-[17px] w-[280px]"></div>

        <div class="shimmer float-right h-[17px] w-[75px]"></div>
    </div>
</div>