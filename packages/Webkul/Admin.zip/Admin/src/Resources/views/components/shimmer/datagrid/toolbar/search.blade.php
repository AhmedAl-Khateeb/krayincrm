<div class="flex w-full items-center gap-x-1.5">
    <div class="shimmer h-[38px] w-[264px] rounded-lg"></div>

    <div class="shimmer h-[38px] w-[66px] rounded-lg"></div>
</div>
