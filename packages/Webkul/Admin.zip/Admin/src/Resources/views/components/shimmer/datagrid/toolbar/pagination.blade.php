<div class="flex items-center gap-x-2">
    <div>
        <p class="shimmer h-[17px] w-[75px]"></p>
    </div>

    <div class="flex items-center gap-x-2">
        <div class="shimmer h-[38px] w-[72px] rounded-md"></div>

        <p class="shimmer h-[17px] w-[75px]"></p>

        <div class="flex items-center gap-1">
            <div class="shimmer h-[38px] w-[38px] rounded-md"></div>

            <div class="shimmer h-[38px] w-[38px] rounded-md"></div>
        </div>
    </div>
</div>