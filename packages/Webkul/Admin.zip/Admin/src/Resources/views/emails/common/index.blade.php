@component('admin::emails.layout')
   {!! $body !!}
@endcomponent
